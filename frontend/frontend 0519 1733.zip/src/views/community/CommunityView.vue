<template>
  <div>
    <div>
      <h2>영화 몽타주</h2>
      <button>질문하기</button>
    </div>
    <div>
      <QuestionItem/>
    </div>
  </div>
</template>

<script>
import QuestionItem from '@/components/community/QuestionItem.vue';
export default {
  name:'CommunityView',
  components:{
    QuestionItem,
  }
}
</script>

<style>

</style>