<template>
  <div>
    <h1>Challenge</h1>
    <QuizItem/>
  </div>
</template>

<script>
import QuizItem from '@/components/community/QuizItem.vue'
export default {
  name :'ChallengeView',
  components : {
    QuizItem,
  }

}
</script>

<style>

</style>