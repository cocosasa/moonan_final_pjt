<template>
  <div class="question-item">
    <h3>이 영화를 10년 후에 찾아주세요..</h3>
    <p>....내용....</p>
  </div>
</template>

<script>
export default {
  name:'QuestionItem',
}
</script>

<style>
.question-item{
  height: 100px;
  width: 100%;
  background-color: whitesmoke;
}
</style>